package models;

public class Pais {

        private String Country;

    private String Slug;

    private String ISO2;

    public Pais(String country) {
        Country = country;
    }

    public String getCountry() {
        return Country;
    }





    public String getSlug() {
        return Slug;
    }


    public void setSlug(String slug) {
        this.Slug = slug;
    }


    public String getISO2() {
        return ISO2;
    }


    public void setISO2(String iSO2) {
        this.ISO2 = iSO2;
    }




}
