package adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import cr.ac.ucr.laboratorio2_android.PaisActivity;
import cr.ac.ucr.laboratorio2_android.R;
import models.Pais;

public class ListaPaisAdapter extends RecyclerView.Adapter<ListaPaisAdapter.CountryViewHolder>{

    private List<Pais> countriesList;
    private Context context;

    public ListaPaisAdapter(List<Pais> countriesList, Context context) {
        this.countriesList = countriesList;
        this.context = context;
    }

    @NonNull
    @Override
    public CountryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View listItem = inflater.inflate(R.layout.countries_list_item, parent, false);
        ListaPaisAdapter.CountryViewHolder viewHolder = new ListaPaisAdapter.CountryViewHolder(listItem);

        return viewHolder;

    }

    @Override
    public void onBindViewHolder(@NonNull final CountryViewHolder holder, int position) {
        final Pais pais = countriesList.get(position);
        holder.name.setText(pais.getCountry());

        holder.itemLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // Toast.makeText(context, "El pais seleccionado es: "+ pais.getCountry(), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(context, PaisActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("country", holder.name.getText());
                context.startActivity(intent);

            }
        });
    }

    @Override
    public int getItemCount() {
        return countriesList.size();
    }

    //View holder para lograr llenar el contenido de cada item
    public static class CountryViewHolder extends RecyclerView.ViewHolder {
        public TextView name;
        public ConstraintLayout itemLayout;

        public CountryViewHolder(@NonNull View itemView) {
            super(itemView);
            this.name = (TextView) itemView.findViewById(R.id.tv_name);
            this.itemLayout = (ConstraintLayout) itemView.findViewById(R.id.cl_countries_list_item);
        }
    }
}
