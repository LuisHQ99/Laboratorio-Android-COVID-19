package Interface;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import models.EstadoPais;
import models.Pais;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface InterfaceCovid {
    Date date = new Date();


    @GET("countries")
    Call<List<Pais>> getPais();

    Date d = new Date();
    // CharSequence s  = DateFormat.format("MMMM d, yyyy ", d.getTime());
    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
    String formattedDate = df.format(d.getTime());
 /*
 @GET("method?page={page}.json")
Call<Void> method(@Path("page") int page);
?from={date}.json"+"T00:00:00Z&to=2020-05-31T00:00:00Z
https://api.covid19api.com/country/south-africa/status/confirmed?from=2020-03-01T00:00:00Z&to=2020-04-01T00:00:00Z
  */
   // @GET("status/confirmed?from={date1}T00:00:00Z&to=2020-05-31T00:00:00Z")
//, @Query("param2") String param2
    //Call<List<ByCountry>> getByCountry(@Query("date1") String date1);
   // @GET("status/confirmed?from={param1}T00:00:00Z&to=2020-05-31T00:00:00Z")
  //  Call<List<ByCountry>> getByCountry ( @Query("param1") String param1);



        /*String BASE_URL = "https://api.test.com/";
        String API_KEY = "SFSDF24242353434";*/

        @GET("status/confirmed?from=") //i.e https://api.test.com/Search?
        Call<List<EstadoPais>> getEstadoPais(@Query("one") String one, @Query("two") String two );


}
