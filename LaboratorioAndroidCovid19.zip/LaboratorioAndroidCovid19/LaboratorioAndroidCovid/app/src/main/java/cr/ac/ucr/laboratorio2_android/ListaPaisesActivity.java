package cr.ac.ucr.laboratorio2_android;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.app.LauncherActivity;
import android.content.Context;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.List;


import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import Interface.InterfaceCovid;
import adapters.ListaPaisAdapter;

import models.Pais;


public class ListaPaisesActivity extends AppCompatActivity {

    public RecyclerView countries_list_recycler;
    public List<Pais> countriesList = new ArrayList<>();
    public List<Pais> countries = new ArrayList<>();
    public List<Pais> aux = new ArrayList<>();
    LauncherActivity.ListItem listItem = new LauncherActivity.ListItem();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_countries_list);
        obtenerPais();

    }

    //se consume el web api del coronaviros

    private void obtenerPais() {

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.covid19api.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        InterfaceCovid interfaceCovid = retrofit.create(InterfaceCovid.class);
        Call<List<Pais>> call = interfaceCovid.getPais();

        countries_list_recycler = findViewById(R.id.countries_list_recycler);
        ListaPaisAdapter adapter = new ListaPaisAdapter(countries, this);
        countries_list_recycler.setLayoutManager(new LinearLayoutManager(this));
        countries_list_recycler.setAdapter(adapter);

        final Context context = this;
        call.enqueue(new Callback<List<Pais>>() {
            @Override
            public void onResponse(Call<List<Pais>> call, Response<List<Pais>> response) {
                if (!response.isSuccessful()) {
                }
                countries = response.body();
                countries_list_recycler.setAdapter(new ListaPaisAdapter(countries, context));
            }

            @Override
            public void onFailure(Call<List<Pais>> call, Throwable t) {

            }
        });

    }

}
