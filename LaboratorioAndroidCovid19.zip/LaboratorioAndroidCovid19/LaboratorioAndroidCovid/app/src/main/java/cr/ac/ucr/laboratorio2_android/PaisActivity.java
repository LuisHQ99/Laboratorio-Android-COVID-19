package cr.ac.ucr.laboratorio2_android;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import Interface.InterfaceCovid;
import models.EstadoPais;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import java.util.Date;

public class PaisActivity extends AppCompatActivity {
    TextView textView;
    TextView myAwesomeTextView;
    private String paisSeleccionado;
    public List<EstadoPais> countryList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.by_country);
        paisSeleccionado = getIntent().getStringExtra("country");
        myAwesomeTextView = (TextView)findViewById(R.id.tv_detail_country);

        this.getByCountry();

    }

    private void getByCountry(){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.covid19api.com/country/"+ paisSeleccionado +"/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        InterfaceCovid interfaceCovid = retrofit.create(InterfaceCovid.class);
        Date d = new Date();
        // CharSequence s  = DateFormat.format("MMMM d, yyyy ", d.getTime());
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate = df.format(d.getTime());
        String strDate = String.valueOf(df.format(d));

        Call<List<EstadoPais>> call = interfaceCovid.getEstadoPais(formattedDate,strDate);
        call.enqueue(new Callback<List<EstadoPais>>() {
            public void onResponse(Call<List<EstadoPais>> call, Response<List<EstadoPais>> response) {
                if (!response.isSuccessful()) {
                    /*error en la respuesta*/
                    myAwesomeTextView.setText("Fallo");
                }
                countryList = response.body();




                //myAwesomeTextView.setText(countryList.get(0).getCountry() + "\n"+ "Cases " + countryList.get(countryList.size() - 1).getCases());
               int aux = countryList.size()-1;
                myAwesomeTextView.setText(
                        "Nombre: "+countryList.get(aux).getCountry() +"\n"+
                                "Código País: "+countryList.get(aux).getCountryCode()+"\n"+
                                "Latitud: "+ countryList.get(aux).getLat() +"\n"+
                                "Longitud: "+ countryList.get(aux).getLon() +"\n"+
                                "Casos: "+countryList.get(aux).getCases() +"\n"+
                                "Estado: "+ countryList.get(aux).getStatus() +"\n"+
                                "Fecha: "+ countryList.get(aux).getDate());


            }
            @Override
            public void onFailure(Call<List<EstadoPais>> call, Throwable t) {
                myAwesomeTextView.setText("Fallo");
            }
        });
    }
}
